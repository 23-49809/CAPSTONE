<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\APIhub;

class GoogleCloudApihubV1AgentRegistrySyncConfig extends \Google\Model
{
  /**
   * Optional. If true, the MCP data sync to the Agent Registry will be
   * disabled. The default value is false.
   *
   * @var bool
   */
  public $disabled;

  /**
   * Optional. If true, the MCP data sync to the Agent Registry will be
   * disabled. The default value is false.
   *
   * @param bool $disabled
   */
  public function setDisabled($disabled)
  {
    $this->disabled = $disabled;
  }
  /**
   * @return bool
   */
  public function getDisabled()
  {
    return $this->disabled;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(GoogleCloudApihubV1AgentRegistrySyncConfig::class, 'Google_Service_APIhub_GoogleCloudApihubV1AgentRegistrySyncConfig');
